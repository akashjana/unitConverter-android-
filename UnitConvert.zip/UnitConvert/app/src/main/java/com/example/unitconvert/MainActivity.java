package com.example.unitconvert;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private TextView textView2;
    private EditText editTextNumber1;

    private Button button2;
    private TextView textView4;
    private EditText editTextNumber2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        textView2 = findViewById(R.id.textView2);
        editTextNumber1 = findViewById(R.id.editTextNumber);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, "Button clicked", Toast.LENGTH_SHORT).show();
                String s1 = editTextNumber1.getText().toString();
                int kg1 = Integer.parseInt(s1);
                double pound1 = 2.205 * kg1;
                textView2.setText("Pound is " + pound1);

            }
        });

        button2 = findViewById(R.id.button2);
        textView4 = findViewById(R.id.textView4);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s2 = editTextNumber2.getText().toString();
                int pound2 = Integer.parseInt(s2);
                double kg2 = 0.4535 * pound2;
                textView4.setText("Kg is " + kg2);
            }
        });
    }
}